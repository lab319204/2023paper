# 读取 `bayesTFR` 自带的子国家级 TFR 示例数据
my.subtfr.file <- file.path(find.package("bayesTFR"), 'extdata', 'subnational_tfr_template.txt')
subtfr <- read.delim(my.subtfr.file, check.names=FALSE)
head(subtfr)
# `nat.dir` 目录存放国家级预测数据
nat.dir <- file.path(find.package("bayesTFR"), "ex-data", "bayesTFR.output")
# 设定存储子国家预测的目录
subnat.dir <- tempfile()

# 运行子国家 TFR 预测（澳大利亚 = 36，加拿大 = 124）
preds <- tfr.predict.subnat(
  c(36, 124),                     # 选择国家代码
  my.tfr.file = my.subtfr.file,   # 子国家级 TFR 数据
  sim.dir = nat.dir,              # 国家级 TFR 预测目录
  output.dir = subnat.dir,        # 预测结果保存目录
  start.year = 2018               # 预测开始年份
)
names(preds)  # 显示预测结果的国家
get.countries.table(preds[["36"]])  # 查看澳大利亚的区域列表
summary(preds[["36"]], "Queensland")  # 查看昆士兰州（Queensland）的预测摘要
