#数据来源：广东省2020、2010普查资料以及广东省2015年1%人口调查资料
#主要目的：计算整理出广东省各地区2010、2015、2020年总和生育率并预测2025-2050年总和生育率

# 加载必要的包
library(readxl)
library(dplyr)
library(openxlsx) 
library(tidyr)
library(zoo)

#一、2015年1%人口调查数据
#数据引入
gd_2015 <-read_excel("2015各地区分性别年龄人口数据.xlsx")
#删除全是 NA 的行
gd_2015 <- gd_2015[rowSums(is.na(gd_2015)) != ncol(gd_2015), ]
# 对第二行进行填充
gd_2015[2, ] <- t(na.locf(t(gd_2015[2, ]), na.rm = FALSE, fromLast = FALSE))
# 合并第 2、3 行作为新的列名
new_colnames <- paste0(as.character(gd_2015[2, ]), "_", as.character(gd_2015[3, ]))
new_colnames <- gsub("_NA", "", new_colnames)  # 去除可能的 "_NA"
# 删除前 3 行，并赋予新的列名
gd_2015 <- gd_2015[-c(1:3), ]  # 删除前 3 行
colnames(gd_2015) <- new_colnames  # 赋予新列名
# 重置行索引
gd_2015 <- gd_2015 %>% mutate_all(as.character)  # 转换为字符，防止列类型混乱
rownames(gd_2015) <- NULL  # 重置索引
# 将第二列及其后所有列转换为数值
gd_2015[, 2:ncol(gd_2015)] <- lapply(gd_2015[, 2:ncol(gd_2015)], function(x) as.numeric(as.character(x)))
# 计算 19、22、25、28、31、34、37 列的和（育龄妇女人数）
gd_2015$育龄妇女人数 <- rowSums(gd_2015[, c(19, 22, 25, 28, 31, 34, 37)], na.rm = TRUE)
# 确保取出的数据是向量而不是数据框
gd_2015$生育率 <- ifelse(gd_2015[[71]] == 0, NA, (gd_2015[[5]] / gd_2015[[71]]) * 35)

#二、2010、2020生育率数据引入
gd_2010 <-read_excel("2010广东各地区育龄妇女年龄别生育率.xlsx")
# 将第二行作为列名
colnames(gd_2010) <- as.character(gd_2010[2, ])
# 删除前两行
gd_2010 <- gd_2010[-c(1, 2), ]
# 重置行号
rownames(gd_2010) <- NULL
gd_2020 <-read_excel("2020广东各地区育龄妇女年龄别生育率.xlsx")
# 将第二行作为列名
colnames(gd_2020) <- as.character(gd_2020[2, ])
# 删除前两行
gd_2020 <- gd_2020[-c(1, 2), ]
# 重置行号
rownames(gd_2020) <- NULL

#三、生育率数据准备
# 将 gd_2020、gd_2020 和 gd_2015 的第一列重命名为 "地区"
colnames(gd_2010)[1] <- "地区"
colnames(gd_2020)[1] <- "地区"
colnames(gd_2015)[1] <- "地区"
# 删除 "市辖区" 的行
gd_2020 <- gd_2020 %>% filter(地区 != "市辖区")
gd_2010 <- gd_2010 %>% filter(地区 != "市辖区")
gd_2015 <- gd_2015 %>% filter(地区 != "市辖区")
# 去掉地区列可能存在的空格
gd_2020$地区 <- trimws(gd_2020$地区)
gd_2010$地区 <- trimws(gd_2010$地区)
gd_2015$地区 <- trimws(gd_2015$地区)
# 将省份统一为广东
gd_2020[1, 1] <- "广东"
gd_2010[1, 1] <- "广东"
gd_2015[1, 1] <- "广东"

# 选择 gd_2020 的第一列和最后一列
gd_birth <- gd_2020 %>% select(1, last_col())
# 选择 gd_2010 和 gd_2015 的最后一列
gd_2010_last <- gd_2010 %>% select(1, last_col())  # 假设第一列是地区
gd_2015_last <- gd_2015 %>% select(1, last_col())  # 假设第一列是地区
# 以地区为键进行拼接
gd_birth <- gd_birth %>%
  left_join(gd_2010_last, by = names(gd_2010_last)[1]) %>%
  left_join(gd_2015_last, by = names(gd_2015_last)[1])

# 重新命名列名
colnames(gd_birth) <- c("地区", "2020", "2010", "2015")
# 调整列的顺序（确保2020、2010、2015按时间顺序排列）
gd_birth <- gd_birth %>% select(地区, `2010`, `2015`, `2020`)
# 转换为数值类型、对2010年和2020年的数据乘以0.001
gd_birth <- gd_birth %>%
  mutate(`2010` = as.numeric(`2010`) * 0.001,
         `2020` = as.numeric(`2020`) * 0.001)

# 写入数据
write.xlsx(gd_birth, "gd_birth.xlsx", rowNames = FALSE)


#四、使用 bayesTFR 预测 2025-2050 年的生育率
# 加载必要的库
#wpp2024包地址：https://github.com/PPgp/wpp2024.git
#bayesTFR包地址：
library(wpp2024)
library(dplyr)
library(bayesTFR)
library(openxlsx)
library(readxl)
library(tidyr)

# ✅ **国家级TFR 预测**

# 🔹 运行 Phase I & II MCMC 预测
run.tfr.mcmc(
  output.dir = "tfr_simulation_中国",
  iter = 3000,
  nr.chains = 3,
  replace.output = TRUE,
  annual = TRUE,
  my.tfr.file = "china_tfr_annual_fixed.txt",
  wpp.year = 2024,
  start.year = 1950,
  present.year = 2023
)

# 🔹 运行 Phase III MCMC
run.tfr3.mcmc(
  sim.dir = "tfr_simulation_中国",
  iter = 10000,   # 增加 MCMC 迭代次数
  nr.chains = 3,  # 确保链数匹配
  replace.output = TRUE
)

# 🔹 预测未来 TFR
tfr_pred <- tfr.predict(
  sim.dir = "tfr_simulation_中国",
  end.year = 2050,
  burnin = 1000,  
  burnin3 = 100,  
  nr.traj = 1000
)

# ✅ **广东省及各区县级 TFR 预测**

# 🔹  区县级数据准备

# 📌 读取 Excel 文件
gd_birth <- read.xlsx("gd_birth.xlsx")
# 📌 确保数据是数值型
colnames(gd_birth) <- c("地区", "地区代码", "2010", "2015", "2020")
gd_birth <- gd_birth %>% mutate(across(-地区, as.numeric)) %>% na.omit()
# 📌 重新命名列 & 添加国家代码
gd_birth <- gd_birth %>%
  rename(name = 地区, reg_code = 地区代码) %>%
  mutate(country_code = 156) %>%
  select(country_code, name, reg_code, everything())
# 确保 reg_code 为整数
gd_birth$reg_code <- as.integer(gd_birth$reg_code)
# 📌 定义插值年份
years <- c(2010, 2015, 2020)
new_years <- seq(2010, 2020, by = 1)
# 📌 进行线性插值计算
interpolated_data <- gd_birth %>%
  gather(year, tfr, -name, -reg_code) %>%
  mutate(year = as.numeric(year)) %>%
  group_by(name, reg_code) %>%
  complete(year = new_years) %>%
  arrange(name, reg_code, year) %>%
  group_by(name, reg_code) %>%
  mutate(tfr = approx(years, tfr[match(years, year)], year, method = "linear", rule = 2)$y) %>%
  spread(year, tfr) %>%
  select(-ncol(.)) # 删除最后一列
# 📌 添加国家 & 观测信息
tfr_final <- interpolated_data %>%
  mutate(country_code = 156, country = "China", last.observed = 2020, include_code = 2) %>%
  select(country_code, country, reg_code, name, everything())
# 📌 保存插值数据
write.table(tfr_final, "subnational_tfr_interpolated.txt", sep = "\t", row.names = FALSE, quote = FALSE)

# 🔹  运行区县级 TFR 预测
preds <- tfr.predict.subnat(
  countries = 156,  
  my.tfr.file = "subnational_tfr_interpolated.txt",
  sim.dir = "tfr_simulation_中国",
  output.dir = "tfr_simulation_广东",
  start.year = 2021
)

# ✅ **提取 & 保存区县级 TFR 预测数据**

# 📌 获取区县名称 & 代码
county_table <- get.countries.table(preds[["156"]])
county_list <- county_table$name
county_codes <- county_table$code

# 📌 创建空数据框
all_tfr_data <- data.frame()
valid_counties <- 0  # 计数器

# 🔹 遍历所有区县并提取 TFR 预测数据
for (i in seq_along(county_list)) {
  county <- county_list[i]
  county_code <- county_codes[i]
  
  # 获取当前区县的 TFR 预测数据
  tfr_summary <- summary(preds[["156"]], county)
  
  # 检查是否有数据
  if (!is.null(tfr_summary$projections)) {
    tfr_data <- as.data.frame(tfr_summary$projections)
    
    # 确保数据行数匹配 31 年（2020-2050）
    if (nrow(tfr_data) == length(2020:2050)) {
      # 添加年份 & 区县信息
      tfr_data$Year <- 2020:2050
      tfr_data$County <- county
      tfr_data$County_Code <- county_code
      
      # 重新排列列顺序
      tfr_data <- tfr_data %>% select(County, County_Code, Year, everything())
      
      # 绑定数据
      all_tfr_data <- bind_rows(all_tfr_data, tfr_data)
      valid_counties <- valid_counties + 1
    } else {
      warning(paste("⚠ 数据行数异常：", county, "（有", nrow(tfr_data), "行，期望 31 行）"))
    }
  } else {
    warning(paste("⚠ 无数据，跳过：", county))
  }
}

# 📌 确保有数据可保存
if (nrow(all_tfr_data) == 0) {
  stop("❌ 没有区县的数据成功导出，请检查 `preds` 是否正确！")
}
# 🔹 按 County_Code 和 Year 升序排序 & 重新设置行号
all_tfr_data <- all_tfr_data %>%
  arrange(County_Code, Year)

rownames(all_tfr_data) <- NULL
# 🔹 保存最终预测数据
write.csv(all_tfr_data, file = "广东各区县TFR2021-2025预测.csv", row.names = FALSE)

